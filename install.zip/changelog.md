# v1.2 - 11/29/2023
* Add device-specific mod for Moto G Stylus 2023 (non-5G) (gnevan).
* This mod just improves the headphone jack's output range to full.

* Also updated NotoColorEmoji.ttf to be the most recently available
* copy of AppleColorEmoji.ttf from iOS 16.4, preventing abscence of emojis.

* Also added much custom logic between all the *.sh scripts.

* Re-implemented system/product/fonts/NotoColorEmoji.ttf to be a symlink to
* system/fonts/NotoColorEmoji.ttf to help save space on the near-50M TTF file.

# v1.1 - 11/18/2023
* Add LICENSE to specify GPLv3 terms, and bundle it within the ZIP

# v1.0 - 10/25/2023
* Initial release
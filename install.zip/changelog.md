# v1.2 - 11/29/2023
* Add file for my specific device, to work around quiet headphone jack output
* Update NotoColorEmoji.ttf file to latest iOS emoji color set available on the Internet
* Add functions in install & uninstall scripts to specifically prevent Android from trying to update emojis using /data/fonts folder

# v1.1 - 11/18/2023
* Add LICENSE to specify GPLv3 terms, and bundle it within the ZIP

# v1.0 - 10/25/2023
* Initial release

# v1.1 - 11/18/2023
* Add LICENSE to specify GPLv3 terms, and bundle it within the ZIP

# v1.0 - 10/25/2023
* Initial release